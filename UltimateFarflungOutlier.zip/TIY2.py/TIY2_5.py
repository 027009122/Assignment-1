#name = "Mahatma Gandhi"
#print("Mahatma Gandhi" + " said," " Live as if you were to die tomorrow")