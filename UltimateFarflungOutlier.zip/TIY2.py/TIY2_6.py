#famous_person = "Mahatma Gandhi"
#message = "Live as if you were to die tomorrow"
#print (famous_person + ":" + message)