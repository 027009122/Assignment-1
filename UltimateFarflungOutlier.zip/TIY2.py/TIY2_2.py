#message = "Hello MrMan"
#print(message)
#message1 = "Hello Kman"
#print (message1)