name=' \tkayden\n\trocks\n\t:) '
print(name)
#Kayden does indeed rock
