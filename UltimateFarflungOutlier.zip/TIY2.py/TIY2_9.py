fav_number=13

message="is my lucky number"
print(f"{fav_number} {message}")