#name = "kayden"
#new_name = name.capitalize ()
#print(name ,new_name)
#new_name=name .upper()
#print(name ,new_name)
#new_name=name .lower()
#print(name ,new_name)