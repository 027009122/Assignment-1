invintation = ["XXXTentacion","Miyabi","Dave Chappelle"]
message = "Good aftetnoon " + invintation[0] + " Would you like to come join my party this Saturday at 8"
message1 = "Good aftetnoon " + invintation[1] + " Would you like to come join my party this Saturday at 8"
message2 = "Good aftetnoon " + invintation[2] + " Would you like to come join my party this Saturday at 8"
print (message)
print (message1)
print (message2)