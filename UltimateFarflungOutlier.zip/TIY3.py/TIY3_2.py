names = ["Miyabi", "Jordyn"]
message = "My girlfriends name is " + names[0]
print(message)
message1 = "My friends name is" + names[1]
print(message1)