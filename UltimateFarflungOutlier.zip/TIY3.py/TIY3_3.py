transportation = ["car","bus","bike","walk","scooter", "plane","train"]
message ="I would like to ride on a " + transportation[6] + " to Texas."
print (message)
message1="Last summer I went to Myrtle Beach on a " + transportation[5]+"."
print (message1)
message2="I love to ride " + transportation[4] +" when im downtown."
print (message2)
message3 = "Since i dont have a car i have to " + transportation[3]+"."
print (message3)
message4="When going to the gas station by my house i can either " + transportation[3] + " or ride my " + transportation[2]+"."
print (message4)
message5  = "People who cant afford " + transportation[0] + " and typically have to use the " + transportation[1] +"."
print (message5)