places= ["Las Vegas","Paris","Flordia","Atlanta","Texas"]

print(places)

print(sorted(places))

print(places)

print(sorted(places, reverse=True))

print(places)

places.reverse()
print(places)

places.reverse()
print(places)

places.sort()
print(places)

places.sort(reverse=True)
print(places)