names = ["Miyabi", "Jordyn"]
print (names[0])
print (names[1])