invites = ['Jacob', 'Miyabi', 'Jimmy', 'Dave Chappelle', 'Johnny']
print ("I have invited") 
print (len(invites))