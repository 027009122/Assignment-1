invites =["XXXTentacion","Miyabi","Dave Chappelle"]
print("Hey everyone, I found a new table thats bigger, so im inviting a couple more people to the party!")
del invites[0]
invites.insert(0, "Jacob")
invites.insert(2, "Jimmy")
invites.append("Johnny")
print(invites)
print("Hello Jacob you have been invited to my birthday dinner at Paulas, i hope to see you there!")
print("Hello Miyabi you have been invited to my birthday dinner at Paulas, i hope to see you there!")
print("Hello Jimmy you have been invited to my birthday dinner at Paulas, i hope to see you there!")
print("Hello Dave you have been invited to my birthday dinner at Paulas, i hope to see you there!")
print("Hello Johnny you have been invited to my birthday dinner at Paulas, i hope to see you there!")
print (invites)